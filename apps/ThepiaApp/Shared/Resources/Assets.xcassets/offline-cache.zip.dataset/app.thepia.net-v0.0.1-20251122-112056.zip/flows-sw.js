const j = [
  {
    id: "journey-001",
    client_id: "demo",
    app_id: "flows",
    title: "Employee Onboarding - Sarah Chen",
    description: "Complete all onboarding tasks before first day",
    status: "active",
    invited_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    started_at: /* @__PURE__ */ new Date("2025-10-05T00:00:00Z"),
    due_date: /* @__PURE__ */ new Date("2025-11-01T00:00:00Z"),
    owner_id: "hr-manager-123",
    participants: ["sarah-chen-456", "hr-manager-123", "it-admin-789"],
    primary_participant_id: "sarah-chen-456",
    progress_percentage: 35,
    current_step: "security-training",
    completed_steps: ["account-setup", "welcome-video"],
    created_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-10T00:00:00Z"),
    metadata: {
      department: "Engineering",
      start_date: "2025-11-01",
      location: "Remote",
      manager: "John Smith"
    }
  },
  {
    id: "journey-002",
    client_id: "demo",
    app_id: "flows",
    title: "Exit Process - Mike Johnson",
    description: "Offboarding checklist for departing employee",
    status: "completed",
    invited_at: /* @__PURE__ */ new Date("2025-09-15T00:00:00Z"),
    started_at: /* @__PURE__ */ new Date("2025-09-16T00:00:00Z"),
    ended_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    owner_id: "hr-manager-123",
    participants: ["mike-johnson-789", "hr-manager-123"],
    primary_participant_id: "mike-johnson-789",
    progress_percentage: 100,
    completed_steps: [
      "return-equipment",
      "knowledge-transfer",
      "exit-interview",
      "access-revocation"
    ],
    created_at: /* @__PURE__ */ new Date("2025-09-15T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    metadata: {
      department: "Marketing",
      last_day: "2025-10-01",
      reason: "New opportunity"
    }
  },
  {
    id: "journey-003",
    client_id: "demo",
    app_id: "flows",
    title: "Q4 2025 Performance Review - Team Alpha",
    description: "Complete performance reviews for all team members",
    status: "invited",
    invited_at: /* @__PURE__ */ new Date("2025-10-08T00:00:00Z"),
    due_date: /* @__PURE__ */ new Date("2025-12-15T00:00:00Z"),
    owner_id: "team-lead-999",
    participants: ["team-lead-999", "hr-manager-123"],
    progress_percentage: 0,
    created_at: /* @__PURE__ */ new Date("2025-10-08T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-08T00:00:00Z"),
    metadata: {
      department: "Engineering",
      team: "Alpha",
      review_period: "Q4-2025",
      team_size: 8
    }
  }
], E = [
  {
    id: "task-001",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-001",
    title: "Meet the team",
    description: "Introduction meeting with team members",
    status: "completed",
    assigned_to: "sarah-chen-456",
    assigned_by: "hr-manager-123",
    due_date: /* @__PURE__ */ new Date("2025-10-15T00:00:00Z"),
    started_at: /* @__PURE__ */ new Date("2025-10-08T00:00:00Z"),
    completed_at: /* @__PURE__ */ new Date("2025-10-12T00:00:00Z"),
    order: 0,
    priority: "high",
    created_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-12T00:00:00Z"),
    metadata: {
      meeting_link: "https://meet.thepia.com/team-intro",
      attendees: ["manager", "team-lead", "mentor"]
    }
  },
  {
    id: "task-002",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-001",
    title: "Complete security training",
    description: "Watch security videos and pass the quiz (80% minimum)",
    status: "in_progress",
    assigned_to: "sarah-chen-456",
    assigned_by: "hr-manager-123",
    due_date: /* @__PURE__ */ new Date("2025-10-20T00:00:00Z"),
    started_at: /* @__PURE__ */ new Date("2025-10-10T00:00:00Z"),
    estimated_duration: 60,
    order: 1,
    priority: "high",
    created_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-10T00:00:00Z"),
    metadata: {
      training_module: "SEC-101",
      required_score: 80,
      current_progress: 45
    }
  },
  {
    id: "task-003",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-001",
    title: "Setup development environment",
    description: "Install required tools and access repositories",
    status: "pending",
    assigned_to: "sarah-chen-456",
    assigned_by: "it-admin-789",
    due_date: /* @__PURE__ */ new Date("2025-10-25T00:00:00Z"),
    order: 2,
    priority: "medium",
    estimated_duration: 120,
    depends_on: ["task-002"],
    created_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    metadata: {
      tools: ["VSCode", "Docker", "Git", "Node.js"],
      repos: ["main-app", "api-server", "mobile-app"]
    }
  },
  {
    id: "task-004",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-001",
    title: "Review company handbook",
    description: "Read and acknowledge company policies and procedures",
    status: "pending",
    assigned_to: "sarah-chen-456",
    assigned_by: "hr-manager-123",
    due_date: /* @__PURE__ */ new Date("2025-10-18T00:00:00Z"),
    order: 3,
    priority: "medium",
    estimated_duration: 30,
    created_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    metadata: {
      handbook_url: "https://docs.thepia.com/handbook",
      sections: ["code-of-conduct", "benefits", "pto-policy", "remote-work"]
    }
  },
  {
    id: "task-101",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-002",
    title: "Return equipment",
    description: "Return laptop, monitor, and access badge",
    status: "completed",
    assigned_to: "mike-johnson-789",
    assigned_by: "it-admin-789",
    due_date: /* @__PURE__ */ new Date("2025-10-01T00:00:00Z"),
    completed_at: /* @__PURE__ */ new Date("2025-09-30T00:00:00Z"),
    order: 0,
    priority: "high",
    created_at: /* @__PURE__ */ new Date("2025-09-15T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-09-30T00:00:00Z"),
    metadata: {
      equipment: ["MacBook Pro", 'Dell Monitor 27"', "Access Badge"],
      return_location: "IT Department"
    }
  },
  {
    id: "task-102",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-002",
    title: "Knowledge transfer",
    description: "Document ongoing projects and transfer knowledge to team",
    status: "completed",
    assigned_to: "mike-johnson-789",
    assigned_by: "team-lead-999",
    due_date: /* @__PURE__ */ new Date("2025-09-28T00:00:00Z"),
    completed_at: /* @__PURE__ */ new Date("2025-09-27T00:00:00Z"),
    order: 1,
    priority: "high",
    created_at: /* @__PURE__ */ new Date("2025-09-15T00:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-09-27T00:00:00Z"),
    metadata: {
      documentation_url: "https://docs.thepia.com/projects/handoff",
      projects: ["Q4 Campaign", "Website Redesign", "Social Media Strategy"]
    }
  }
], v = [
  {
    id: "evidence-001",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-001",
    task_id: "task-002",
    type: "screen",
    filename: "security-training-completion.webm",
    content_type: "video/webm",
    size: 5242880,
    duration: 180,
    dimensions: { width: 1920, height: 1080 },
    storage_type: "local",
    storage_path: "/evidence/screen-recordings/training.webm",
    recorded_by: "sarah-chen-456",
    recorded_at: /* @__PURE__ */ new Date("2025-10-10T14:30:00Z"),
    device_info: {
      platform: "web",
      browser: "Chrome 119"
    },
    processing_status: "completed",
    transcription_status: "completed",
    transcription: "User completed modules 1-5 of security training.",
    created_at: /* @__PURE__ */ new Date("2025-10-10T14:30:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-10T14:35:00Z"),
    metadata: {
      quiz_score: 95,
      modules_completed: 5
    }
  }
], q = [
  {
    id: "comment-001",
    client_id: "demo",
    app_id: "flows",
    journey_id: "journey-001",
    task_id: "task-002",
    message: "Great progress on the security training!",
    message_type: "text",
    author_id: "hr-manager-123",
    created_at: /* @__PURE__ */ new Date("2025-10-10T15:00:00Z"),
    updated_at: /* @__PURE__ */ new Date("2025-10-10T15:00:00Z"),
    metadata: {}
  }
], I = "flows-db", x = 3;
let f = null;
async function y() {
  return new Promise((e, t) => {
    const a = indexedDB.open("flows-tmp", 1);
    a.onerror = () => t(a.error), a.onsuccess = () => {
      f = a.result, e();
    }, a.onupgradeneeded = (s) => {
      const o = s.target.result;
      if (!o.objectStoreNames.contains("auth-log")) {
        const r = o.createObjectStore("auth-log", { keyPath: "id", autoIncrement: !0 });
        r.createIndex("timestamp", "timestamp", { unique: !1 }), r.createIndex("event", "event", { unique: !1 }), r.createIndex("url", "url", { unique: !1 });
      }
    };
  });
}
async function h(e, t, a, s) {
  if (!f)
    try {
      await y();
    } catch (r) {
      console.warn("[SW Logger] Failed to initialize database, skipping log:", r);
      return;
    }
  if (!f) {
    console.warn("[SW Logger] Database not available, skipping log");
    return;
  }
  const o = {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    event: e,
    data: t,
    url: a || "service-worker",
    tabId: s
  };
  return new Promise((r, n) => {
    const u = f.transaction(["auth-log"], "readwrite").objectStore("auth-log").add(o);
    u.onsuccess = () => {
      console.log(`[SW Logger] ${e}:`, t), r();
    }, u.onerror = () => {
      console.error("[SW Logger] Failed to write log:", u.error), n(u.error);
    };
  });
}
async function A(e = 50) {
  if (f || await y(), !f)
    throw new Error("Logger database not available");
  return new Promise((t, a) => {
    const n = f.transaction(["auth-log"], "readonly").objectStore("auth-log").index("timestamp").openCursor(null, "prev"), c = [];
    let d = 0;
    n.onsuccess = (u) => {
      const l = u.target.result;
      l && d < e ? (c.push(l.value), d++, l.continue()) : t(c);
    }, n.onerror = () => a(n.error);
  });
}
async function P(e = 100) {
  if (f || await y(), !f)
    throw new Error("Logger database not available");
  return new Promise((t, a) => {
    const o = f.transaction(["auth-log"], "readwrite").objectStore("auth-log"), r = o.index("timestamp"), n = o.count();
    n.onsuccess = () => {
      const c = n.result;
      if (c <= e) {
        t();
        return;
      }
      const d = c - e, u = r.openCursor();
      let l = 0;
      u.onsuccess = (w) => {
        const m = w.target.result;
        m && l < d ? (m.delete(), l++, m.continue()) : (console.log(`[SW Logger] Cleaned up ${l} old log entries`), t());
      }, u.onerror = () => a(u.error);
    }, n.onerror = () => a(n.error);
  });
}
async function U() {
  if (f || await y(), !f)
    throw new Error("Logger database not available");
  return new Promise((e, t) => {
    const o = f.transaction(["auth-log"], "readonly").objectStore("auth-log").getAll();
    o.onsuccess = () => {
      const r = o.result;
      r.sort((n, c) => new Date(n.timestamp).getTime() - new Date(c.timestamp).getTime()), e(r);
    }, o.onerror = () => t(o.error);
  });
}
let i = null, S = !1;
async function b() {
  return new Promise((e, t) => {
    const a = indexedDB.open(I, x);
    a.onerror = () => t(a.error), a.onsuccess = () => {
      i = a.result, e(i);
    }, a.onupgradeneeded = (s) => {
      const o = s.target.result;
      if (!o.objectStoreNames.contains("journeys")) {
        const r = o.createObjectStore("journeys", { keyPath: "id" });
        r.createIndex("client_id", "client_id", { unique: !1 }), r.createIndex("status", "status", { unique: !1 }), r.createIndex("created_at", "created_at", { unique: !1 });
      }
      if (!o.objectStoreNames.contains("tasks")) {
        const r = o.createObjectStore("tasks", { keyPath: "id" });
        r.createIndex("journey_id", "journey_id", { unique: !1 }), r.createIndex("status", "status", { unique: !1 }), r.createIndex("assigned_to", "assigned_to", { unique: !1 });
      }
      if (!o.objectStoreNames.contains("attachments")) {
        const r = o.createObjectStore("attachments", { keyPath: "id" });
        r.createIndex("journey_id", "journey_id", { unique: !1 }), r.createIndex("task_id", "task_id", { unique: !1 });
      }
      if (!o.objectStoreNames.contains("evidence")) {
        const r = o.createObjectStore("evidence", { keyPath: "id" });
        r.createIndex("journey_id", "journey_id", { unique: !1 }), r.createIndex("task_id", "task_id", { unique: !1 }), r.createIndex("type", "type", { unique: !1 });
      }
      if (!o.objectStoreNames.contains("comments")) {
        const r = o.createObjectStore("comments", { keyPath: "id" });
        r.createIndex("journey_id", "journey_id", { unique: !1 }), r.createIndex("task_id", "task_id", { unique: !1 });
      }
      if (!o.objectStoreNames.contains("notes")) {
        const r = o.createObjectStore("notes", { keyPath: "id" });
        r.createIndex("journey_id", "journey_id", { unique: !1 }), r.createIndex("task_id", "task_id", { unique: !1 });
      }
      if (!o.objectStoreNames.contains("users")) {
        const r = o.createObjectStore("users", { keyPath: "userId" });
        r.createIndex("email", "email", { unique: !0 }), r.createIndex("lastUsed", "lastUsed", { unique: !1 });
      }
      o.objectStoreNames.contains("auth_sessions") || o.createObjectStore("auth_sessions", { keyPath: "userId" }).createIndex("expiresAt", "expiresAt", { unique: !1 });
    };
  });
}
async function k() {
  if (S || !i) return;
  const a = i.transaction(["journeys"], "readonly").objectStore("journeys").count();
  return new Promise((s) => {
    a.onsuccess = () => {
      if (a.result === 0 && i) {
        console.log("[SW] Database empty, seeding with demo data...");
        const r = i.transaction(["journeys"], "readwrite").objectStore("journeys");
        for (const m of j)
          r.add(m);
        const c = i.transaction(["tasks"], "readwrite").objectStore("tasks");
        for (const m of E)
          c.add(m);
        const u = i.transaction(["evidence"], "readwrite").objectStore("evidence");
        for (const m of v)
          u.add(m);
        const w = i.transaction(["comments"], "readwrite").objectStore("comments");
        for (const m of q)
          w.add(m);
        console.log("[SW] Seeded database with demo data");
      }
      S = !0, s();
    };
  });
}
async function Z(e, t) {
  i || (await b(), await k());
  const [a, s] = e.split(".");
  if (a === "query")
    return B(s, t);
  if (a === "mutation")
    return O(s, t);
  if (a === "sync")
    return F(s);
  if (a === "auth")
    return G(s, t);
  if (a === "debug")
    return Q(s, t);
  throw new Error(`Unknown procedure: ${e}`);
}
async function B(e, t) {
  switch (e) {
    case "journeys":
      return M(t);
    case "journeyById":
      return D(t.id);
    case "tasks":
      return W(t);
    case "tasksByJourney":
      return C(t.journeyId, t);
    case "evidence":
      return z(t);
    case "evidenceByTask":
      return L(t.taskId, t);
    default:
      throw new Error(`Unknown query method: ${e}`);
  }
}
async function O(e, t) {
  switch (e) {
    case "insertJourney":
      return N(t.data);
    case "updateJourney":
      return R(t.id, t.data);
    case "deleteJourney":
      return V(t.id);
    case "insertTask":
      return $(t.data);
    case "updateTask":
      return J(t.id, t.data);
    default:
      throw new Error(`Unknown mutation method: ${e}`);
  }
}
async function M(e = {}) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const r = i.transaction(["journeys"], "readonly").objectStore("journeys").getAll();
    r.onsuccess = () => {
      var c;
      let n = r.result;
      (c = e.filter) != null && c.eq && (n = n.filter((d) => Object.entries(e.filter.eq).every(([u, l]) => d[u] === l))), e.orderBy && n.sort((d, u) => {
        for (const { column: l, ascending: w = !0 } of e.orderBy) {
          const m = d[l], g = u[l];
          if (m < g) return w ? -1 : 1;
          if (m > g) return w ? 1 : -1;
        }
        return 0;
      }), e.limit && (n = n.slice(0, e.limit)), t(n);
    }, r.onerror = () => a(r.error);
  });
}
async function D(e) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const r = i.transaction(["journeys"], "readonly").objectStore("journeys").get(e);
    r.onsuccess = () => t(r.result || null), r.onerror = () => a(r.error);
  });
}
async function W(e = {}) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const r = i.transaction(["tasks"], "readonly").objectStore("tasks").getAll();
    r.onsuccess = () => {
      var c;
      let n = r.result;
      (c = e.filter) != null && c.eq && (n = n.filter((d) => Object.entries(e.filter.eq).every(([u, l]) => d[u] === l))), e.orderBy && n.sort((d, u) => {
        for (const { column: l, ascending: w = !0 } of e.orderBy) {
          const m = d[l], g = u[l];
          if (m < g) return w ? -1 : 1;
          if (m > g) return w ? 1 : -1;
        }
        return 0;
      }), t(n);
    }, r.onerror = () => a(r.error);
  });
}
async function C(e, t = {}) {
  return new Promise((a, s) => {
    if (!i) return s(new Error("DB not initialized"));
    const c = i.transaction(["tasks"], "readonly").objectStore("tasks").index("journey_id").getAll(e);
    c.onsuccess = () => {
      let d = c.result;
      t.orderBy && d.sort((u, l) => {
        for (const { column: w, ascending: m = !0 } of t.orderBy) {
          const g = u[w], _ = l[w];
          if (g < _) return m ? -1 : 1;
          if (g > _) return m ? 1 : -1;
        }
        return 0;
      }), a(d);
    }, c.onerror = () => s(c.error);
  });
}
async function z(e = {}) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const r = i.transaction(["evidence"], "readonly").objectStore("evidence").getAll();
    r.onsuccess = () => t(r.result), r.onerror = () => a(r.error);
  });
}
async function L(e, t = {}) {
  return new Promise((a, s) => {
    if (!i) return s(new Error("DB not initialized"));
    const c = i.transaction(["evidence"], "readonly").objectStore("evidence").index("task_id").getAll(e);
    c.onsuccess = () => a(c.result), c.onerror = () => s(c.error);
  });
}
async function N(e) {
  const t = {
    id: crypto.randomUUID(),
    ...e,
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  return new Promise((a, s) => {
    if (!i) return s(new Error("DB not initialized"));
    const n = i.transaction(["journeys"], "readwrite").objectStore("journeys").add(t);
    n.onsuccess = () => a(t), n.onerror = () => s(n.error);
  });
}
async function R(e, t) {
  const a = await D(e);
  if (!a)
    throw new Error("Journey not found");
  const s = {
    ...a,
    ...t,
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  return new Promise((o, r) => {
    if (!i) return r(new Error("DB not initialized"));
    const d = i.transaction(["journeys"], "readwrite").objectStore("journeys").put(s);
    d.onsuccess = () => o(s), d.onerror = () => r(d.error);
  });
}
async function V(e) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const r = i.transaction(["journeys"], "readwrite").objectStore("journeys").delete(e);
    r.onsuccess = () => t(), r.onerror = () => a(r.error);
  });
}
async function $(e) {
  const t = {
    id: crypto.randomUUID(),
    ...e,
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  return new Promise((a, s) => {
    if (!i) return s(new Error("DB not initialized"));
    const n = i.transaction(["tasks"], "readwrite").objectStore("tasks").add(t);
    n.onsuccess = () => a(t), n.onerror = () => s(n.error);
  });
}
async function J(e, t) {
  return new Promise((a, s) => {
    if (!i) return s(new Error("DB not initialized"));
    const n = i.transaction(["tasks"], "readonly").objectStore("tasks").get(e);
    n.onsuccess = () => {
      const c = n.result;
      if (!c) {
        s(new Error("Task not found"));
        return;
      }
      const d = {
        ...c,
        ...t,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      };
      if (!i) return s(new Error("DB not initialized"));
      const w = i.transaction(["tasks"], "readwrite").objectStore("tasks").put(d);
      w.onsuccess = () => a(d), w.onerror = () => s(w.error);
    }, n.onerror = () => s(n.error);
  });
}
async function F(e, t) {
  switch (e) {
    case "status":
      return { tables: [], synced: !0 };
    default:
      throw new Error(`Unknown sync method: ${e}`);
  }
}
async function G(e, t) {
  switch (e) {
    case "saveSession":
      if (!t) throw new Error("Session data required for saveSession");
      return await K(t);
    case "getSession":
      return H();
    case "clearSession":
      await X();
      return;
    case "saveUser":
      if (!t) throw new Error("User data required for saveUser");
      await Y(t);
      return;
    case "getUser":
      if (typeof t != "string") throw new Error("userId required for getUser");
      return ee(t);
    case "clearUser":
      if (typeof t != "string") throw new Error("userId required for clearUser");
      await te(t);
      return;
    case "updateUserMetadata":
      if (!(t != null && t.userId)) throw new Error("userId required for updateUserMetadata");
      if (!(t != null && t.metadata)) throw new Error("metadata required for updateUserMetadata");
      await T(t.userId, t.metadata);
      return;
    case "patchMetadata":
      if (!(t != null && t.userId)) throw new Error("userId required for patchMetadata");
      if (!(t != null && t.patch)) throw new Error("patch required for patchMetadata");
      if (!(t != null && t.appCode)) throw new Error("appCode required for patchMetadata");
      if (!(t != null && t.token)) throw new Error("token required for patchMetadata");
      return await re(t.userId, t.patch, t.appCode, t.token);
    default:
      throw new Error(`Unknown auth method: ${e}`);
  }
}
async function Q(e, t) {
  switch (e) {
    case "getRecentLogs":
      return A((t == null ? void 0 : t.limit) || 50);
    case "clearDebugLogs":
      await P(0);
      return;
    case "exportLogs":
      return U();
    default:
      throw new Error(`Unknown debug method: ${e}`);
  }
}
async function K(e) {
  return new Promise((t, a) => {
    var d, u;
    if (!i) return a(new Error("DB not initialized"));
    const s = (/* @__PURE__ */ new Date()).toISOString(), o = i.transaction(["users", "auth_sessions"], "readwrite");
    o.objectStore("users").put({
      userId: e.userId,
      email: e.email,
      name: e.name,
      emailVerified: e.emailVerified,
      metadata: e.metadata,
      lastUsed: s,
      authMethod: e.authMethod
    });
    const n = o.objectStore("auth_sessions");
    console.log("[SW] Saving session with tokens:", {
      userId: e.userId,
      refreshToken: ((d = e.refreshToken) == null ? void 0 : d.substring(0, 8)) + "...",
      expiresAt: new Date(e.expiresAt).toISOString(),
      hasSupabaseToken: !!e.supabaseToken,
      supabaseTokenPreview: ((u = e.supabaseToken) == null ? void 0 : u.substring(0, 20)) + "...",
      supabaseExpiresAt: e.supabaseExpiresAt ? new Date(e.supabaseExpiresAt).toISOString() : "none",
      savedAt: new Date(s).toISOString()
    });
    const c = n.put({
      userId: e.userId,
      email: e.email,
      accessToken: e.accessToken,
      refreshToken: e.refreshToken,
      expiresAt: e.expiresAt,
      refreshedAt: e.refreshedAt,
      authMethod: e.authMethod,
      supabaseToken: e.supabaseToken,
      supabaseExpiresAt: e.supabaseExpiresAt,
      savedAt: s
    });
    c.onsuccess = () => {
      console.log("[SW] Auth session saved:", e.userId), t(e);
    }, c.onerror = () => a(c.error);
  });
}
async function H() {
  return new Promise((e, t) => {
    if (!i) return t(new Error("DB not initialized"));
    const o = i.transaction(["auth_sessions"], "readonly").objectStore("auth_sessions").getAll();
    o.onsuccess = () => {
      const r = o.result;
      if (r.length === 0) {
        e(null);
        return;
      }
      r.sort((u, l) => new Date(l.savedAt).getTime() - new Date(u.savedAt).getTime());
      const n = r[0], c = n.expiresAt <= Date.now(), d = !!n.supabaseToken;
      console.log("[SW] Auth session loaded:", {
        userId: n.userId,
        status: c ? "expired" : "valid",
        hasSupabaseToken: d,
        supabaseTokenExpiry: n.supabaseExpiresAt ? new Date(n.supabaseExpiresAt).toISOString() : "none"
      }), e(n);
    }, o.onerror = () => t(o.error);
  });
}
async function X() {
  return new Promise((e, t) => {
    if (!i) return t(new Error("DB not initialized"));
    const o = i.transaction(["auth_sessions"], "readwrite").objectStore("auth_sessions").clear();
    o.onsuccess = () => {
      console.log("[SW] Auth sessions cleared (user profiles preserved)"), e();
    }, o.onerror = () => t(o.error);
  });
}
async function Y(e) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const s = (/* @__PURE__ */ new Date()).toISOString(), n = i.transaction(["users"], "readwrite").objectStore("users").put({
      userId: e.userId,
      email: e.email,
      name: e.name,
      avatar: e.avatar,
      emailVerified: e.emailVerified,
      createdAt: e.createdAt,
      lastLoginAt: e.lastLoginAt,
      metadata: e.metadata,
      authMethod: e.authMethod,
      lastUsed: s
    });
    n.onsuccess = () => {
      console.log("[SW] User profile saved:", e.userId), t();
    }, n.onerror = () => a(n.error);
  });
}
async function ee(e) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const r = i.transaction(["users"], "readonly").objectStore("users").get(e);
    r.onsuccess = () => {
      const n = r.result;
      if (!n) {
        t(null);
        return;
      }
      t({
        userId: n.userId,
        email: n.email,
        name: n.name,
        avatar: n.avatar,
        emailVerified: n.emailVerified,
        createdAt: n.createdAt,
        lastLoginAt: n.lastLoginAt,
        metadata: n.metadata,
        authMethod: n.authMethod
      });
    }, r.onerror = () => a(r.error);
  });
}
async function te(e) {
  return new Promise((t, a) => {
    if (!i) return a(new Error("DB not initialized"));
    const r = i.transaction(["users"], "readwrite").objectStore("users").delete(e);
    r.onsuccess = () => {
      console.log("[SW] User profile cleared:", e), t();
    }, r.onerror = () => a(r.error);
  });
}
async function T(e, t) {
  return new Promise((a, s) => {
    if (!i) return s(new Error("DB not initialized"));
    const r = i.transaction(["users"], "readwrite").objectStore("users"), n = r.get(e);
    n.onsuccess = () => {
      const c = n.result;
      if (!c) {
        console.warn("[SW] User not found for metadata update:", e), a();
        return;
      }
      const d = {
        ...c,
        metadata: {
          ...c.metadata,
          ...t
        },
        lastUsed: (/* @__PURE__ */ new Date()).toISOString()
      }, u = r.put(d);
      u.onsuccess = () => {
        console.log("[SW] User metadata updated:", e, t), ae(e, d.metadata), a();
      }, u.onerror = () => s(u.error);
    }, n.onerror = () => s(n.error);
  });
}
async function re(e, t, a, s) {
  try {
    console.log("[SW] Patching metadata for user:", e, { patchKeys: Object.keys(t) });
    const o = await fetch(`/api/${a}/metadata`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${s}`
      },
      body: JSON.stringify({ patch: t })
    });
    if (!o.ok) {
      const n = await o.json().catch(() => ({}));
      throw new Error(`Failed to patch metadata: ${o.status} ${n.error || o.statusText}`);
    }
    const r = await o.json();
    if (!r.success || !r.metadata)
      throw new Error(`Invalid response from metadata patch: ${r.error || "unknown error"}`);
    return await T(e, r.metadata), console.log("[SW] Metadata patched successfully for user:", e), r.metadata;
  } catch (o) {
    throw console.error("[SW] Failed to patch metadata:", o), o;
  }
}
function ae(e, t) {
  try {
    const a = new BroadcastChannel("auth-metadata-updates");
    a.postMessage({
      type: "METADATA_UPDATED",
      userId: e,
      metadata: t,
      timestamp: Date.now()
    }), a.close(), console.log("[SW] Metadata update broadcasted to all tabs:", e);
  } catch (a) {
    console.warn("[SW] Failed to broadcast metadata update:", a);
  }
}
const p = "1.0.0";
self.addEventListener("message", async (e) => {
  var n, c;
  const t = e.data;
  if (t.type === "LOG_AUTH_EVENT") {
    const { event: d, data: u, url: l, tabId: w } = t;
    h(d, u, l, w);
    return;
  }
  const { id: a, type: s, procedure: o, payload: r } = t;
  if (s === "INIT_CONFIG") {
    console.log("[SW] Configuration received:", r);
    return;
  }
  if (!(s !== "request" || !o))
    try {
      const d = await Z(o, r);
      (n = e.ports[0]) == null || n.postMessage({
        id: a,
        type: "response",
        payload: d
      });
    } catch (d) {
      (c = e.ports[0]) == null || c.postMessage({
        id: a,
        type: "response",
        payload: null,
        error: {
          code: "RPC_ERROR",
          message: d instanceof Error ? d.message : "Unknown error"
        }
      });
    }
});
self.addEventListener("install", (e) => {
  console.log(`[SW] Installing version ${p}`), e.waitUntil(
    Promise.all([
      b().then(() => k()),
      y()
    ]).then(() => (h("SW_INSTALL", { version: p }), self.skipWaiting()))
  );
});
self.addEventListener("activate", (e) => {
  console.log(`[SW] Activating version ${p}`), e.waitUntil(
    self.clients.claim().then(() => {
      h("SW_ACTIVATE", { version: p });
    })
  );
});
console.log(`[SW] Flows Service Worker ${p} loaded`);
//# sourceMappingURL=flows-sw.js.map
