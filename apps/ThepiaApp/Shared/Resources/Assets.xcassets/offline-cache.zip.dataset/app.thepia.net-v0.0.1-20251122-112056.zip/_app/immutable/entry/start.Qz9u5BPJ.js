import{l as o,a as r}from"../chunks/AED0UPAO.js";export{o as load_css,r as start};
