const r=n=>typeof n>"u"||n===null||n===!1?"":n;export{r as p};
