import{g as t}from"./BJ0HmCBf.js";const n=()=>"We sent you an e-mail, open it to confirm. 😊",s=(o={},e={})=>(e.locale??t(),n());export{s};
