class m{static floatTo16BitPCM(e){const t=new ArrayBuffer(e.length*2),s=new DataView(t);let n=0;for(let r=0;r<e.length;r++,n+=2){let a=Math.max(-1,Math.min(1,e[r]));s.setInt16(n,a<0?a*32768:a*32767,!0)}return t}static mergeBuffers(e,t){const s=new Uint8Array(e.byteLength+t.byteLength);return s.set(new Uint8Array(e),0),s.set(new Uint8Array(t),e.byteLength),s.buffer}_packData(e,t){return[new Uint8Array([t,t>>8]),new Uint8Array([t,t>>8,t>>16,t>>24])][e]}pack(e,t){if(t!=null&&t.bitsPerSample)if(t!=null&&t.channels){if(!(t!=null&&t.data))throw new Error('Missing "data"')}else throw new Error('Missing "channels"');else throw new Error('Missing "bitsPerSample"');const{bitsPerSample:s,channels:n,data:r}=t,a=["RIFF",this._packData(1,52),"WAVE","fmt ",this._packData(1,16),this._packData(0,1),this._packData(0,n.length),this._packData(1,e),this._packData(1,e*n.length*s/8),this._packData(0,n.length*s/8),this._packData(0,s),"data",this._packData(1,n[0].length*n.length*s/8),r],i=new Blob(a,{type:"audio/mpeg"}),l=URL.createObjectURL(i);return{blob:i,url:l,channelCount:n.length,sampleRate:e,duration:r.byteLength/(n.length*e*2)}}}globalThis.WavPacker=m;const x=[4186.01,4434.92,4698.63,4978.03,5274.04,5587.65,5919.91,6271.93,6644.88,7040,7458.62,7902.13],B=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"],p=[],b=[];for(let u=1;u<=8;u++)for(let e=0;e<x.length;e++){const t=x[e];p.push(t/Math.pow(2,8-u)),b.push(B[e]+u)}const A=[32,2e3],C=p.filter((u,e)=>p[e]>A[0]&&p[e]<A[1]),D=b.filter((u,e)=>p[e]>A[0]&&p[e]<A[1]);class w{static getFrequencies(e,t,s,n="frequency",r=-100,a=-30){s||(s=new Float32Array(e.frequencyBinCount),e.getFloatFrequencyData(s));const i=t/2,l=1/s.length*i;let h,o,c;if(n==="music"||n==="voice"){const d=n==="voice"?C:p,f=Array(d.length).fill(r);for(let v=0;v<s.length;v++){const S=v*l,P=s[v];for(let y=d.length-1;y>=0;y--)if(S>d[y]){f[y]=Math.max(f[y],P);break}}h=f,o=n==="voice"?C:p,c=n==="voice"?D:b}else h=Array.from(s),o=h.map((d,f)=>l*f),c=o.map(d=>`${d.toFixed(2)} Hz`);const g=h.map(d=>Math.max(0,Math.min((d-r)/(a-r),1)));return{values:new Float32Array(g),frequencies:o,labels:c}}constructor(e,t=null){if(this.fftResults=[],t){const{length:s,sampleRate:n}=t,r=new OfflineAudioContext({length:s,sampleRate:n}),a=r.createBufferSource();a.buffer=t;const i=r.createAnalyser();i.fftSize=8192,i.smoothingTimeConstant=.1,a.connect(i);const l=1/60,h=s/n,o=c=>{const g=l*c;g<h&&r.suspend(g).then(()=>{const k=new Float32Array(i.frequencyBinCount);i.getFloatFrequencyData(k),this.fftResults.push(k),o(c+1)}),c===1?r.startRendering():r.resume()};a.start(0),o(1),this.audio=e,this.context=r,this.analyser=i,this.sampleRate=n,this.audioBuffer=t}else{const s=new AudioContext,n=s.createMediaElementSource(e),r=s.createAnalyser();r.fftSize=8192,r.smoothingTimeConstant=.1,n.connect(r),r.connect(s.destination),this.audio=e,this.context=s,this.analyser=r,this.sampleRate=this.context.sampleRate,this.audioBuffer=null}}getFrequencies(e="frequency",t=-100,s=-30){let n=null;if(this.audioBuffer&&this.fftResults.length){const r=this.audio.currentTime/this.audio.duration,a=Math.min(r*this.fftResults.length|0,this.fftResults.length-1);n=this.fftResults[a]}return w.getFrequencies(this.analyser,this.sampleRate,n,e,t,s)}async resumeIfSuspended(){return this.context.state==="suspended"&&await this.context.resume(),!0}}globalThis.AudioAnalysis=w;const I=`
class StreamProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.hasStarted = false;
    this.hasInterrupted = false;
    this.outputBuffers = [];
    this.bufferLength = 128;
    this.write = { buffer: new Float32Array(this.bufferLength), trackId: null };
    this.writeOffset = 0;
    this.trackSampleOffsets = {};
    this.port.onmessage = (event) => {
      if (event.data) {
        const payload = event.data;
        if (payload.event === 'write') {
          const int16Array = payload.buffer;
          const float32Array = new Float32Array(int16Array.length);
          for (let i = 0; i < int16Array.length; i++) {
            float32Array[i] = int16Array[i] / 0x8000; // Convert Int16 to Float32
          }
          this.writeData(float32Array, payload.trackId);
        } else if (
          payload.event === 'offset' ||
          payload.event === 'interrupt'
        ) {
          const requestId = payload.requestId;
          const trackId = this.write.trackId;
          const offset = this.trackSampleOffsets[trackId] || 0;
          this.port.postMessage({
            event: 'offset',
            requestId,
            trackId,
            offset,
          });
          if (payload.event === 'interrupt') {
            this.hasInterrupted = true;
          }
        } else {
          throw new Error(\`Unhandled event "\${payload.event}"\`);
        }
      }
    };
  }

  writeData(float32Array, trackId = null) {
    let { buffer } = this.write;
    let offset = this.writeOffset;
    for (let i = 0; i < float32Array.length; i++) {
      buffer[offset++] = float32Array[i];
      if (offset >= buffer.length) {
        this.outputBuffers.push(this.write);
        this.write = { buffer: new Float32Array(this.bufferLength), trackId };
        buffer = this.write.buffer;
        offset = 0;
      }
    }
    this.writeOffset = offset;
    return true;
  }

  process(inputs, outputs, parameters) {
    const output = outputs[0];
    const outputChannelData = output[0];
    const outputBuffers = this.outputBuffers;
    if (this.hasInterrupted) {
      this.port.postMessage({ event: 'stop' });
      return false;
    } else if (outputBuffers.length) {
      this.hasStarted = true;
      const { buffer, trackId } = outputBuffers.shift();
      for (let i = 0; i < outputChannelData.length; i++) {
        outputChannelData[i] = buffer[i] || 0;
      }
      if (trackId) {
        this.trackSampleOffsets[trackId] =
          this.trackSampleOffsets[trackId] || 0;
        this.trackSampleOffsets[trackId] += buffer.length;
      }
      return true;
    } else if (this.hasStarted) {
      this.port.postMessage({ event: 'stop' });
      return false;
    } else {
      return true;
    }
  }
}

registerProcessor('stream_processor', StreamProcessor);
`,_=new Blob([I],{type:"application/javascript"}),F=URL.createObjectURL(_),R=F;class E{constructor({sampleRate:e=44100}={}){this.scriptSrc=R,this.sampleRate=e,this.context=null,this.stream=null,this.analyser=null,this.trackSampleOffsets={},this.interruptedTrackIds={}}async connect(){this.context=new AudioContext({sampleRate:this.sampleRate}),this.context.state==="suspended"&&await this.context.resume();try{await this.context.audioWorklet.addModule(this.scriptSrc)}catch(t){throw console.error(t),new Error(`Could not add audioWorklet module: ${this.scriptSrc}`)}const e=this.context.createAnalyser();return e.fftSize=8192,e.smoothingTimeConstant=.1,this.analyser=e,!0}getFrequencies(e="frequency",t=-100,s=-30){if(!this.analyser)throw new Error("Not connected, please call .connect() first");return w.getFrequencies(this.analyser,this.sampleRate,null,e,t,s)}_start(){const e=new AudioWorkletNode(this.context,"stream_processor");return e.connect(this.context.destination),e.port.onmessage=t=>{const{event:s}=t.data;if(s==="stop")e.disconnect(),this.stream=null;else if(s==="offset"){const{requestId:n,trackId:r,offset:a}=t.data,i=a/this.sampleRate;this.trackSampleOffsets[n]={trackId:r,offset:a,currentTime:i}}},this.analyser.disconnect(),e.connect(this.analyser),this.stream=e,!0}add16BitPCM(e,t="default"){if(typeof t!="string")throw new Error("trackId must be a string");if(this.interruptedTrackIds[t])return;this.stream||this._start();let s;if(e instanceof Int16Array)s=e;else if(e instanceof ArrayBuffer)s=new Int16Array(e);else throw new Error("argument must be Int16Array or ArrayBuffer");return this.stream.port.postMessage({event:"write",buffer:s,trackId:t}),s}async getTrackSampleOffset(e=!1){if(!this.stream)return null;const t=crypto.randomUUID();this.stream.port.postMessage({event:e?"interrupt":"offset",requestId:t});let s;for(;!s;)s=this.trackSampleOffsets[t],await new Promise(r=>setTimeout(()=>r(),1));const{trackId:n}=s;return e&&n&&(this.interruptedTrackIds[n]=!0),s}async interrupt(){return this.getTrackSampleOffset(!0)}}globalThis.WavStreamPlayer=E;const q=`
class AudioProcessor extends AudioWorkletProcessor {

  constructor() {
    super();
    this.port.onmessage = this.receive.bind(this);
    this.initialize();
  }

  initialize() {
    this.foundAudio = false;
    this.recording = false;
    this.chunks = [];
  }

  /**
   * Concatenates sampled chunks into channels
   * Format is chunk[Left[], Right[]]
   */
  readChannelData(chunks, channel = -1, maxChannels = 9) {
    let channelLimit;
    if (channel !== -1) {
      if (chunks[0] && chunks[0].length - 1 < channel) {
        throw new Error(
          \`Channel \${channel} out of range: max \${chunks[0].length}\`
        );
      }
      channelLimit = channel + 1;
    } else {
      channel = 0;
      channelLimit = Math.min(chunks[0] ? chunks[0].length : 1, maxChannels);
    }
    const channels = [];
    for (let n = channel; n < channelLimit; n++) {
      const length = chunks.reduce((sum, chunk) => {
        return sum + chunk[n].length;
      }, 0);
      const buffers = chunks.map((chunk) => chunk[n]);
      const result = new Float32Array(length);
      let offset = 0;
      for (let i = 0; i < buffers.length; i++) {
        result.set(buffers[i], offset);
        offset += buffers[i].length;
      }
      channels[n] = result;
    }
    return channels;
  }

  /**
   * Combines parallel audio data into correct format,
   * channels[Left[], Right[]] to float32Array[LRLRLRLR...]
   */
  formatAudioData(channels) {
    if (channels.length === 1) {
      // Simple case is only one channel
      const float32Array = channels[0].slice();
      const meanValues = channels[0].slice();
      return { float32Array, meanValues };
    } else {
      const float32Array = new Float32Array(
        channels[0].length * channels.length
      );
      const meanValues = new Float32Array(channels[0].length);
      for (let i = 0; i < channels[0].length; i++) {
        const offset = i * channels.length;
        let meanValue = 0;
        for (let n = 0; n < channels.length; n++) {
          float32Array[offset + n] = channels[n][i];
          meanValue += channels[n][i];
        }
        meanValues[i] = meanValue / channels.length;
      }
      return { float32Array, meanValues };
    }
  }

  /**
   * Converts 32-bit float data to 16-bit integers
   */
  floatTo16BitPCM(float32Array) {
    const buffer = new ArrayBuffer(float32Array.length * 2);
    const view = new DataView(buffer);
    let offset = 0;
    for (let i = 0; i < float32Array.length; i++, offset += 2) {
      let s = Math.max(-1, Math.min(1, float32Array[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    return buffer;
  }

  /**
   * Retrieves the most recent amplitude values from the audio stream
   * @param {number} channel
   */
  getValues(channel = -1) {
    const channels = this.readChannelData(this.chunks, channel);
    const { meanValues } = this.formatAudioData(channels);
    return { meanValues, channels };
  }

  /**
   * Exports chunks as an audio/wav file
   */
  export() {
    const channels = this.readChannelData(this.chunks);
    const { float32Array, meanValues } = this.formatAudioData(channels);
    const audioData = this.floatTo16BitPCM(float32Array);
    return {
      meanValues: meanValues,
      audio: {
        bitsPerSample: 16,
        channels: channels,
        data: audioData,
      },
    };
  }

  receive(e) {
    const { event, id } = e.data;
    let receiptData = {};
    switch (event) {
      case 'start':
        this.recording = true;
        break;
      case 'stop':
        this.recording = false;
        break;
      case 'clear':
        this.initialize();
        break;
      case 'export':
        receiptData = this.export();
        break;
      case 'read':
        receiptData = this.getValues();
        break;
      default:
        break;
    }
    // Always send back receipt
    this.port.postMessage({ event: 'receipt', id, data: receiptData });
  }

  sendChunk(chunk) {
    const channels = this.readChannelData([chunk]);
    const { float32Array, meanValues } = this.formatAudioData(channels);
    const rawAudioData = this.floatTo16BitPCM(float32Array);
    const monoAudioData = this.floatTo16BitPCM(meanValues);
    this.port.postMessage({
      event: 'chunk',
      data: {
        mono: monoAudioData,
        raw: rawAudioData,
      },
    });
  }

  process(inputList, outputList, parameters) {
    // Copy input to output (e.g. speakers)
    // Note that this creates choppy sounds with Mac products
    const sourceLimit = Math.min(inputList.length, outputList.length);
    for (let inputNum = 0; inputNum < sourceLimit; inputNum++) {
      const input = inputList[inputNum];
      const output = outputList[inputNum];
      const channelCount = Math.min(input.length, output.length);
      for (let channelNum = 0; channelNum < channelCount; channelNum++) {
        input[channelNum].forEach((sample, i) => {
          output[channelNum][i] = sample;
        });
      }
    }
    const inputs = inputList[0];
    // There's latency at the beginning of a stream before recording starts
    // Make sure we actually receive audio data before we start storing chunks
    let sliceIndex = 0;
    if (!this.foundAudio) {
      for (const channel of inputs) {
        sliceIndex = 0; // reset for each channel
        if (this.foundAudio) {
          break;
        }
        if (channel) {
          for (const value of channel) {
            if (value !== 0) {
              // find only one non-zero entry in any channel
              this.foundAudio = true;
              break;
            } else {
              sliceIndex++;
            }
          }
        }
      }
    }
    if (inputs && inputs[0] && this.foundAudio && this.recording) {
      // We need to copy the TypedArray, because the \`process\`
      // internals will reuse the same buffer to hold each input
      const chunk = inputs.map((input) => input.slice(sliceIndex));
      this.chunks.push(chunk);
      this.sendChunk(chunk);
    }
    return true;
  }
}

registerProcessor('audio_processor', AudioProcessor);
`,L=new Blob([q],{type:"application/javascript"}),M=URL.createObjectURL(L),T=M;class O{constructor({sampleRate:e=44100,outputToSpeakers:t=!1,debug:s=!1}={}){this.scriptSrc=T,this.sampleRate=e,this.outputToSpeakers=t,this.debug=!!s,this._deviceChangeCallback=null,this._devices=[],this.stream=null,this.processor=null,this.source=null,this.node=null,this.recording=!1,this._lastEventId=0,this.eventReceipts={},this.eventTimeout=5e3,this._chunkProcessor=()=>{},this._chunkProcessorSize=void 0,this._chunkProcessorBuffer={raw:new ArrayBuffer(0),mono:new ArrayBuffer(0)}}static async decode(e,t=44100,s=-1){const n=new AudioContext({sampleRate:t});let r,a;if(e instanceof Blob){if(s!==-1)throw new Error('Can not specify "fromSampleRate" when reading from Blob');a=e,r=await a.arrayBuffer()}else if(e instanceof ArrayBuffer){if(s!==-1)throw new Error('Can not specify "fromSampleRate" when reading from ArrayBuffer');r=e,a=new Blob([r],{type:"audio/wav"})}else{let o,c;if(e instanceof Int16Array){c=e,o=new Float32Array(e.length);for(let f=0;f<e.length;f++)o[f]=e[f]/32768}else if(e instanceof Float32Array)o=e;else if(e instanceof Array)o=new Float32Array(e);else throw new Error('"audioData" must be one of: Blob, Float32Arrray, Int16Array, ArrayBuffer, Array<number>');if(s===-1)throw new Error('Must specify "fromSampleRate" when reading from Float32Array, In16Array or Array');if(s<3e3)throw new Error('Minimum "fromSampleRate" is 3000 (3kHz)');c||(c=m.floatTo16BitPCM(o));const g={bitsPerSample:16,channels:[o],data:c};a=new m().pack(s,g).blob,r=await a.arrayBuffer()}const i=await n.decodeAudioData(r),l=i.getChannelData(0),h=URL.createObjectURL(a);return{blob:a,url:h,values:l,audioBuffer:i}}log(){return this.debug&&this.log(...arguments),!0}getSampleRate(){return this.sampleRate}getStatus(){return this.processor?this.recording?"recording":"paused":"ended"}async _event(e,t={},s=null){if(s=s||this.processor,!s)throw new Error("Can not send events without recording first");const n={event:e,id:this._lastEventId++,data:t};s.port.postMessage(n);const r=new Date().valueOf();for(;!this.eventReceipts[n.id];){if(new Date().valueOf()-r>this.eventTimeout)throw new Error(`Timeout waiting for "${e}" event`);await new Promise(i=>setTimeout(()=>i(!0),1))}const a=this.eventReceipts[n.id];return delete this.eventReceipts[n.id],a}listenForDeviceChange(e){if(e===null&&this._deviceChangeCallback)navigator.mediaDevices.removeEventListener("devicechange",this._deviceChangeCallback),this._deviceChangeCallback=null;else if(e!==null){let t=0,s=[];const n=a=>a.map(i=>i.deviceId).sort().join(","),r=async()=>{let a=++t;const i=await this.listDevices();a===t&&n(s)!==n(i)&&(s=i,e(i.slice()))};navigator.mediaDevices.addEventListener("devicechange",r),r(),this._deviceChangeCallback=r}return!0}async requestPermission(){const e=await navigator.permissions.query({name:"microphone"});if(e.state==="denied")window.alert("You must grant microphone access to use this feature.");else if(e.state==="prompt")try{(await navigator.mediaDevices.getUserMedia({audio:!0})).getTracks().forEach(n=>n.stop())}catch{window.alert("You must grant microphone access to use this feature.")}return!0}async listDevices(){if(!navigator.mediaDevices||!("enumerateDevices"in navigator.mediaDevices))throw new Error("Could not request user devices");await this.requestPermission();const t=(await navigator.mediaDevices.enumerateDevices()).filter(r=>r.kind==="audioinput"),s=t.findIndex(r=>r.deviceId==="default"),n=[];if(s!==-1){let r=t.splice(s,1)[0],a=t.findIndex(i=>i.groupId===r.groupId);a!==-1&&(r=t.splice(a,1)[0]),r.default=!0,n.push(r)}return n.concat(t)}async begin(e){if(this.processor)throw new Error("Already connected: please call .end() to start a new session");if(!navigator.mediaDevices||!("getUserMedia"in navigator.mediaDevices))throw new Error("Could not request user media");try{const i={audio:!0};e&&(i.audio={deviceId:{exact:e}}),this.stream=await navigator.mediaDevices.getUserMedia(i)}catch{throw new Error("Could not start media stream")}const t=new AudioContext({sampleRate:this.sampleRate}),s=t.createMediaStreamSource(this.stream);try{await t.audioWorklet.addModule(this.scriptSrc)}catch(i){throw console.error(i),new Error(`Could not add audioWorklet module: ${this.scriptSrc}`)}const n=new AudioWorkletNode(t,"audio_processor");n.port.onmessage=i=>{const{event:l,id:h,data:o}=i.data;if(l==="receipt")this.eventReceipts[h]=o;else if(l==="chunk")if(this._chunkProcessorSize){const c=this._chunkProcessorBuffer;this._chunkProcessorBuffer={raw:m.mergeBuffers(c.raw,o.raw),mono:m.mergeBuffers(c.mono,o.mono)},this._chunkProcessorBuffer.mono.byteLength>=this._chunkProcessorSize&&(this._chunkProcessor(this._chunkProcessorBuffer),this._chunkProcessorBuffer={raw:new ArrayBuffer(0),mono:new ArrayBuffer(0)})}else this._chunkProcessor(o)};const r=s.connect(n),a=t.createAnalyser();return a.fftSize=8192,a.smoothingTimeConstant=.1,r.connect(a),this.outputToSpeakers&&(console.warn(`Warning: Output to speakers may affect sound quality,
especially due to system audio feedback preventative measures.
use only for debugging`),a.connect(t.destination)),this.source=s,this.node=r,this.analyser=a,this.processor=n,!0}getFrequencies(e="frequency",t=-100,s=-30){if(!this.processor)throw new Error("Session ended: please call .begin() first");return w.getFrequencies(this.analyser,this.sampleRate,null,e,t,s)}async pause(){if(this.processor){if(!this.recording)throw new Error("Already paused: please call .record() first")}else throw new Error("Session ended: please call .begin() first");return this._chunkProcessorBuffer.raw.byteLength&&this._chunkProcessor(this._chunkProcessorBuffer),this.log("Pausing ..."),await this._event("stop"),this.recording=!1,!0}async record(e=()=>{},t=8192){if(this.processor){if(this.recording)throw new Error("Already recording: please call .pause() first");if(typeof e!="function")throw new Error("chunkProcessor must be a function")}else throw new Error("Session ended: please call .begin() first");return this._chunkProcessor=e,this._chunkProcessorSize=t,this._chunkProcessorBuffer={raw:new ArrayBuffer(0),mono:new ArrayBuffer(0)},this.log("Recording ..."),await this._event("start"),this.recording=!0,!0}async clear(){if(!this.processor)throw new Error("Session ended: please call .begin() first");return await this._event("clear"),!0}async read(){if(!this.processor)throw new Error("Session ended: please call .begin() first");return this.log("Reading ..."),await this._event("read")}async save(e=!1){if(!this.processor)throw new Error("Session ended: please call .begin() first");if(!e&&this.recording)throw new Error("Currently recording: please call .pause() first, or call .save(true) to force");this.log("Exporting ...");const t=await this._event("export");return new m().pack(this.sampleRate,t.audio)}async end(){if(!this.processor)throw new Error("Session ended: please call .begin() first");const e=this.processor;this.log("Stopping ..."),await this._event("stop"),this.recording=!1,this.stream.getTracks().forEach(a=>a.stop()),this.log("Exporting ...");const s=await this._event("export",{},e);return this.processor.disconnect(),this.source.disconnect(),this.node.disconnect(),this.analyser.disconnect(),this.stream=null,this.processor=null,this.source=null,this.node=null,new m().pack(this.sampleRate,s.audio)}async quit(){return this.listenForDeviceChange(null),this.processor&&await this.end(),!0}}globalThis.WavRecorder=O;class V{constructor({sampleRate:e=44100}={}){this.sampleRate=e,this.context=null,this.analyser=null,this.source=null,this.buffer=null,this.isPlaying=!1,this.startTime=0,this.pauseTime=0}async connect(){this.context=new AudioContext({sampleRate:this.sampleRate}),this.context.state==="suspended"&&await this.context.resume();const e=this.context.createAnalyser();return e.fftSize=8192,e.smoothingTimeConstant=.1,this.analyser=e,!0}async loadFile(e){this.context||await this.connect();let t;if(typeof e=="string")t=await(await fetch(e)).arrayBuffer();else if(e instanceof Blob)t=await e.arrayBuffer();else if(e instanceof ArrayBuffer)t=e;else throw new Error("audioInput must be a URL string, ArrayBuffer, or Blob");this.buffer=await this.context.decodeAudioData(t)}play(){if(this.isPlaying)return;if(!this.buffer)throw new Error("No audio buffer loaded. Please call loadFile() first.");this.source=this.context.createBufferSource(),this.source.buffer=this.buffer,this.source.connect(this.analyser),this.analyser.connect(this.context.destination);const e=this.pauseTime||0;this.source.start(0,e),this.startTime=this.context.currentTime-e,this.isPlaying=!0,this.source.onended=()=>{this.isPlaying=!1,this.pauseTime=0}}pause(){this.isPlaying&&(this.source.stop(),this.pauseTime=this.context.currentTime-this.startTime,this.isPlaying=!1)}stop(){this.source&&this.source.stop(),this.isPlaying=!1,this.pauseTime=0}getFrequencies(e="frequency",t=-100,s=-30){if(!this.analyser)throw new Error("Not connected, please call .connect() first");return w.getFrequencies(this.analyser,this.sampleRate,null,e,t,s)}}globalThis.AudioFilePlayer=V;export{O as W};
